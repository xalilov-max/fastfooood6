from django.db import models

class FoodType(models.Model):
    nomi = models.CharField(max_length=100, verbose_name="Taom turi")

    class Meta:
        verbose_name = "Taom turi"
        verbose_name_plural = "Taom turlari"

    def __str__(self):
        return self.nomi


class Food(models.Model):
    food_type = models.ForeignKey(FoodType, on_delete=models.CASCADE, verbose_name="Taom turi")
    nomi = models.CharField(max_length=100, verbose_name="Taom nomi")
    tarkibi = models.TextField(verbose_name="Tarkibi")
    narxi = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Narxi")
    view_count = models.IntegerField(default=0, verbose_name="Ko'rilgan soni")

    class Meta:
        verbose_name = "Taom"
        verbose_name_plural = "Taomlar"

    def __str__(self):
        return self.nomi
