from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import permission_required
from .models import FoodType, Food
from .forms import FoodForm


def index(request):
    food_types = FoodType.objects.all()
    foods = Food.objects.all()
    return render(request, 'menu/index.html', {'food_types': food_types, 'foods': foods})

def food_list(request):
    food_types = FoodType.objects.all()
    foods = Food.objects.all()
    return render(request, 'menu/food_list.html', {'food_types': food_types, 'foods': foods})


def food_detail(request, id):
    food = get_object_or_404(Food, id=id)
    food.view_count += 1 
    food.save()
    return render(request, 'menu/food_detail.html', {'food': food})


@permission_required('menu.add_food')
def food_create(request):
    if request.method == 'POST':
        form = FoodForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('food_list')
    else:
        form = FoodForm()
    return render(request, 'menu/food_form.html', {'form': form})


@permission_required('menu.change_food')
def food_update(request, id):
    food = get_object_or_404(Food, id=id)
    if request.method == 'POST':
        form = FoodForm(request.POST, instance=food)
        if form.is_valid():
            form.save()
            return redirect('food_list')
    else:
        form = FoodForm(instance=food)
    return render(request, 'menu/food_form.html', {'form': form})


@permission_required('menu.delete_food')
def food_delete(request, id):
    food = get_object_or_404(Food, id=id)
    if request.method == 'POST':
        food.delete()
        return redirect('food_list')
    return render(request, 'menu/food_confirm_delete.html', {'food': food})
